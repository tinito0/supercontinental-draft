local m = { version = "1.8" }
local root, sider_dir, active, selected, base_path, status
local clumps_active, clumps_selected
local served = {}
local marks_active, marks_selected
local targets = { DrawPitchEffect = { [2] = true }, pes3ddf_turf3d_2020 = { [1] = true },
    pes3ddf_pitch_2020 = { [2] = true }, pes3ddf_pitch_2020_en = { [2] = true } }
local function read(path)
    local f = io.open(path, "rb")
    if not f then return nil end
    local bytes = f:read("*a"); f:close(); return bytes
end
local function write(path, bytes)
    local f, err = io.open(path, "wb")
    if not f then return false, err end
    local ok, message = f:write(bytes); local closed, close_error = f:close()
    return ok ~= nil and closed ~= nil, message or close_error
end
local function u32(s, p)
    local a,b,c,d = s:byte(p,p+3); assert(d, "Truncated FSOP")
    return a + b*256 + c*65536 + d*16777216
end
local function pack32(n)
    return string.char(n%256,math.floor(n/256)%256,math.floor(n/65536)%256,math.floor(n/16777216)%256)
end
local function parse(bytes)
    local rows, p, names = {}, 1, {}
    while p <= #bytes do
        local n=bytes:byte(p); p=p+1; assert(n and n>0 and p+n-1<=#bytes,"Bad FSOP name")
        local label=bytes:sub(p,p+n-1); p=p+n
        local name=label:gsub("%z+$", ""); assert(not names[name], "Duplicate shader name"); names[name]=true
        local row={name=name,label=label,stages={}}
        for stage=1,2 do
            local size=u32(bytes,p); p=p+4; assert(size>0 and p+size-1<=#bytes,"Bad FSOP length")
            row.stages[stage]=bytes:sub(p,p+size-1); p=p+size
        end
        rows[#rows+1]=row
    end
    assert(#rows==244,"Expected PES21 shader package with 244 pairs")
    return rows
end
local function merge(base, preset, writer)
    local replacements={}
    for _,row in ipairs(parse(preset)) do replacements[row.name]=row end
    local result, count={},0
    for _,row in ipairs(parse(base)) do
        result[#result+1]=string.char(#row.label)..row.label
        for stage=1,2 do
            local bytes=row.stages[stage]
            if targets[row.name] and targets[row.name][stage] then
                assert(replacements[row.name],"Missing turf shader")
                bytes=replacements[row.name].stages[stage]
                if row.name=="DrawPitchEffect" and stage==2 then bytes=writer end
                count=count+1
            end
            result[#result+1]=pack32(#bytes)..bytes
        end
    end
    assert(count==4,"Could not locate all four turf stages")
    return table.concat(result)
end
local function read_settings()
    local values={}
    local text=read(root.."settings.ini") or ""
    -- A whitespace pattern over the whole file can consume a newline after '='.
    -- Parse each line separately. Last duplicate key wins, comments are ignored.
    for line in (text.."\n"):gmatch("([^\r\n]*)[\r\n]") do
        line=line:gsub("^%s+",""):gsub("%s+$","")
        if line~="" and line:sub(1,1)~=";" and line:sub(1,1)~="#" then
            local key,value=line:match("^([%w_]+)%s*=%s*(.*)$")
            if key then values[key:lower()]=value:gsub("%s+$","") end
        end
    end
    return values
end
local function settings()
    local values=read_settings()
    local percent=tonumber(values.percent) or 30
    percent=math.max(0,math.min(100,math.floor(percent/10+.5)*10))
    local marks=tonumber(values.marks_strength) or 100
    marks=math.max(0,math.min(100,math.floor(marks/10+.5)*10))
    return percent,values.base_fsop or "",values.clumps_enabled~="0",marks
end
local function save()
    local text="; Turf Evolution v1.8 - changes apply after restarting PES and Sider\r\npercent = "..selected.."\r\nbase_fsop = "..base_path.."\r\nclumps_enabled = "..(clumps_selected and "1" or "0").."\r\nmarks_strength = "..marks_selected.."\r\n"
    local ok,err=write(root.."settings.ini",text)
    status=ok and "Saved: restart PES and Sider to apply" or "Cannot save settings (folder permissions)"
    if not ok then log("[turf-evolution] Save failed: "..tostring(err)) end
end
function m.key_down(ctx,key)
    if key==0xBD or key==0x6D then selected=math.max(0,selected-10);save()
    elseif key==0xBB or key==0x6B then selected=math.min(100,selected+10);save()
    elseif key==0x43 then clumps_selected=not clumps_selected;save()
    elseif key==0xDB then marks_selected=math.max(0,marks_selected-10);save()
    elseif key==0xDD then marks_selected=math.min(100,marks_selected+10);save() end
end
local function wanted(filename)
    return filename:lower():gsub("/","\\"):gsub("^\\+","")=="shaders\\dx11\\pesshaders_dx11.fsop"
end
local function clump_file(filename)
    if not clumps_active then return nil end
    local f=filename:lower():gsub("/","\\")
    local mode,ext=f:match("asset\\model\\bg\\st%d%d%d\\#win\\st%d%d%d_([dn][fr])%.(fpkd?)$")
    if mode then return "clumps\\Asset\\model\\bg\\st000\\#Win\\st000_"..mode.."."..ext end
    local tex=f:match("asset\\model\\bg\\st%d%d%d\\sourceimages\\tga\\#windx11\\([^\\]+%.ftex)$")
    if tex=="cm000_pape001_bsm_alp.ftex" or tex=="cm000_pape001_nrm.ftex" or tex=="cm000_pape001_srm.ftex" or tex=="cm000_black_mtl.ftex" then
        return "clumps\\Asset\\model\\bg\\st000\\sourceimages\\tga\\#windx11\\"..tex
    end
end
function m.key(ctx,filename)
    if wanted(filename) then return "turf-evolution-v1.8:"..active..":"..marks_active end
    local file=clump_file(filename)
    if file then return "turf-evolution-clump-v1:"..filename end
end
function m.path(ctx,filename,key)
    if wanted(filename) then
        log("[turf-evolution] Serving active="..active.."%, saved="..selected.."%")
        return root.."active.fsop"
    end
    local file=clump_file(filename)
    if file then
        if not served[file] then log("[turf-evolution] Static clumps: "..filename);served[file]=true end
        return root..file
    end
end
function m.overlay(ctx)
    return string.format("TURF EVOLUTION v1.8\nBrown exposure: %d%% active / %d%% saved [-/+]\nMarks strength: %d%% active / %d%% saved [brackets]\nStatic clumps: %s active / %s saved [C]\n%s",active,selected,marks_active,marks_selected,clumps_active and "ON" or "OFF",clumps_selected and "ON" or "OFF",status)
end
function m.init(ctx)
    sider_dir=ctx.sider_dir;root=sider_dir.."content\\turf-evolution\\"
    selected,base_path,clumps_selected,marks_selected=settings();active=selected;clumps_active=clumps_selected;marks_active=marks_selected
    local preset=assert(read(root.."presets\\"..active..".fsop"),"Missing Turf Evolution preset")
    local writer=assert(read(root.."marks\\"..marks_active..".bin"),"Missing marks-strength shader")
    local bytes=merge(preset,preset,writer)
    if base_path~="" then
        local path=base_path
        if not path:match("^%a:[/\\]") and not path:match("^\\\\") then path=sider_dir..path end
        bytes=merge(assert(read(path),"Cannot read base_fsop: "..path),preset,writer)
        log("[turf-evolution] Preserved custom base; replaced only 4 grass stages")
    else parse(preset) end
    local ok,err=write(root.."active.fsop",bytes);assert(ok,"Cannot write active.fsop: "..tostring(err))
    status="Restart PES and Sider after changing saved settings"
    ctx.register("livecpk_make_key",m.key);ctx.register("livecpk_get_filepath",m.path)
    ctx.register("overlay_on",m.overlay);ctx.register("key_down",m.key_down)
    log("[turf-evolution] Initialized brown="..active.."%, marks="..marks_active.."%")
end
return m
