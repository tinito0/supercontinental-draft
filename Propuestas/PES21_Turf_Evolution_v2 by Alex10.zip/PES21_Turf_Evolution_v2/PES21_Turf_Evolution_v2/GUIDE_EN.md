# PES 2021 Turf Evolution v1.7

Smooth tackle wear with green, shortened 3D grass, brown exposed ground, and optional **150 static clumps**. This package retains the shader and model files confirmed working in v1 The unused match-clock diagnostic has been removed.

## Requirements

- PES 2021 and a working Sider installation. Tested setup: Sider 7.3.3.
- Write access to `sider/content/turf-evolution`, where the module saves settings and creates `active.fsop` at startup.

No Python, Blender, installer scripts or match-statistics setting is required to use the mod. Static CLUMPS do not appear progressively or follow tackles.

## Installation — three steps

### 1. Copy the files

Close PES and Sider. Back up `sider.ini`. Extract the ZIP and copy its **modules** and **content** folders into your Sider folder. Merge folders when asked.

Check the result:

```text
sider/
  sider.ini
  modules/
    turf-evolution.lua
  content/
    turf-evolution/
      settings.ini
      presets/
      clumps/
```

Do not create an extra `modules/modules` or `content/content` folder. Do not add a `cpk.root` entry for this mod.

### 2. Enable one module

Add the following line **once**, before the other Lua modules in `sider.ini`:

```ini
lua.module = "turf-evolution.lua"
```
Turf Evolution should come before StadiumServer because they can redirect overlapping stadium resources. Other turf loaders may also compete for those resources; use one loader for the same files.

### 3. Choose your settings

Open `sider/content/turf-evolution/settings.ini`:

```ini
percent = 30
clumps_enabled = 1
```

Save the file, then start Sider and PES normally.

## Settings explained

| Setting | Meaning | Example |
|---|---|---|
| `percent` | Brown exposure strength, 0–100 in steps of 10 | `30` gives more green marks; `80` gives more brown |
| `clumps_enabled` | Enable or disable the separate static clump models | `1` = ON; `0` = OFF |
| `base_fsop` | Optional custom shader package to preserve other shader changes | Leave blank for supplied base-game shaders |

**0%:** damaged areas retain shorter green 3D grass. **100%:** damaged areas show brown ground with their grass blades lowered below the surface. Intermediate values mix the two. Healthy areas retain normal grass. The percentage controls the visual mix, not an exact percentage of tackles or the whole pitch. Values between steps are rounded: 35 becomes 40.

**Clumps ON:** all 150 larger clumps are loaded from the beginning and remain fixed throughout the match. **Clumps OFF:** the separate clump model is not redirected; green/brown wear continues to work. Turning this option off does not remove clumps supplied by another independent stadium/turf mod.

**Restart both PES and Sider after changing settings.** Starting another match alone does not reliably reload the shader or stadium meshes.

## Optional Sider overlay controls

Open the overlay with your configured Sider key, usually Space. Select **TURF EVOLUTION** using your configured module-selection key.

| Key | Action |
|---|---|
| Minus or numpad minus | Reduce brown exposure by 10 |
| Equals/plus or numpad plus | Increase brown exposure by 10 |
| C | Toggle static clumps ON/OFF |

The selection is saved automatically. **Active** shows the currently loaded setting; **saved** shows what will apply after restarting PES and Sider. If the overlay reports that settings cannot be saved, check folder write permissions or edit settings.ini manually with appropriate access.

## Troubleshooting

| Problem | Check |
|---|---|
| No overlay entry | Check the module filename, sider.ini entry, and initialization errors in sider.log |
| Settings do not apply | Close and restart both PES and Sider; compare active and saved values |
| Cannot read base_fsop | Correct the path, keep the custom shader file, or leave the value blank if no custom base is needed |
| Clothing changes disappear | Restore the correct custom base_fsop path and disable its competing shader loader |
| Clumps are absent | Set clumps_enabled to 1, restart, and check clumps folder placement and other turf loaders |
| Stadium/pitch geometry changes unexpectedly | Set clumps_enabled to 0 and restart; stadium archive compatibility varies |
| Other stadium mod still shows clumps when OFF | Disable that mod's own clumps separately |

In `sider.log`, look for `[turf-evolution] Initialized`, `Serving active=...`, and, with clumps enabled, `Static clumps:`. Keep the log and a screenshot when reporting a problem.

## Uninstall / restore your previous setup

Close PES and Sider. Disable this entry:

```ini
;lua.module = "turf-evolution.lua"
```

Re-enable your previous smooth-turf, cloth-time-test or TurfLoader entry if you used one. Use your saved sider.ini as a reference. The copied module and content folder can remain unused or be removed. Keep custom shader base files needed by your other mods.

## Verification

All 11 shader presets and 12 clump assets match the confirmed v1.6 package byte for byte. That version's shader bytecode passed D3D11 creation checks and its appearance was confirmed by the user. v1.7 only removes clock-diagnostic code and cleans up the overlay/settings; its cleaned loader still needs the usual first launch check. Package hashes are provided in PACKAGE_CHECKS.json.
